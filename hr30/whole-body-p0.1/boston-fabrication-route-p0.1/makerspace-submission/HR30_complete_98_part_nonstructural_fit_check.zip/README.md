# HR-30 complete 1:1 nonstructural fit-check bundle

PRELIMINARY - UNPOWERED NONSTRUCTURAL FIT-CHECK / RFQ ROUTE ONLY - NOT APPROVED FOR PROCUREMENT, STRUCTURAL FABRICATION, ASSEMBLY, POWERED TESTING, MOTION, OR ENERGIZATION

This bundle contains 98 bed-normalized binary STL files plus the controlled
plate, print-setting, assembly-traveler and inspection registers.  Every part
is 1:1 millimetres.  Do not scale.  No G-code or slicer profile is released;
the receiving facility must perform printer/material/support/time preflight.
