PRELIMINARY - NOT APPROVED FOR PROCUREMENT, FABRICATION, ASSEMBLY, CONNECTION, POWERED TESTING, MOTION, OR ENERGIZATION

Bundle: HR-V0-LOT-A-TX-BUNDLE-P0.1
Route: R257-RT-03
Organization: East Coast Metrology / ECM, Topsfield MA
State: NOT AUTHORIZED / NOT SENT

Verify payload-manifest.csv before review. No file grants permission to contact, purchase, ship, assemble, connect, power, move or energize anything.
