# UNSENT Project Button Lot A inquiry — R257-RT-01

> **PRELIMINARY - NOT APPROVED FOR PROCUREMENT, FABRICATION, ASSEMBLY, CONNECTION, POWERED TESTING, MOTION, OR ENERGIZATION**

Intended organization: **ROBOTIS America sales/orders**

Official public route: **america@robotis.com; 949-377-0377 ext. 1**
Controlled scope: **R257-RQ-01..08** — sales/order identity, contents, allocation, quote, condition, substitution and shipping questions.

This recipient-specific bundle is a frozen review candidate. It is **NOT AUTHORIZED** and **NOT SENT**. It is not an order, reservation, shipment instruction, work authorization, acceptance limit, assembly instruction or safety approval. Sender identity and reply address remain `SELECTION REQUIRED`.

Return only the included response workbooks with attributable, dated evidence. Do not substitute products, receive articles, incur cost, subcontract work or begin measurement without later configuration-specific written authority.
