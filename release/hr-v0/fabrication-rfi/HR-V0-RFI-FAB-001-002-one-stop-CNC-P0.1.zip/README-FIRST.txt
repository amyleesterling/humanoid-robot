PROJECT BUTTON HR-V0 FABRICATION CAPABILITY / DFM INQUIRY

Packet: RFI-001
Routes: FAB-001;FAB-002
Revision: HR-V0-FAB-RFI-P0.1
Status: PRELIMINARY - CAPABILITY/DFM REQUEST ONLY - NOT A PURCHASE ORDER - DO NOT FABRICATE

PURPOSE
Ask a one-stop CNC supplier whether it can machine the three candidate finished geometries and provide written DFM, inspection and material evidence.

AUTHORIZATION BOUNDARY
- This packet requests capability, DFM, budgetary cost and lead-time information only.
- It is not a purchase order, request to start work, fabrication release or first-article authorization.
- Dimensions and tolerance notes remain preliminary. Critical finished-hole size and location tolerances remain SELECTION REQUIRED.
- Do not fabricate, procure material, program production, or infer omitted geometry from this packet.
- Any later work requires a separately signed authorization tied to an exact repository commit, drawing revision and SHA-256 manifest.

QUESTIONS TO RETURN IN WRITING
1. Can you supply certified 6061-T6 at the stated nominal thicknesses? If not, identify the exact proposed temper and consequences.
2. Can your process hold the candidate 2.70 mm holes and a drawing-controlled location tolerance after those tolerances are released? State minimum achievable values.
3. State stock-thickness tolerance, profile tolerance, flatness basis, edge/deburr condition and inspection method.
4. State material-certificate and first-article inspection options, lead time, setup assumptions and budgetary cost.
5. Identify every geometry, tolerance or documentation issue that must be resolved before a first-article order could be accepted.

CONFIGURATION CONTROL
- MANIFEST.csv hashes every payload file. It intentionally excludes README-FIRST.txt and itself.
- The commit containing this packet plus its outer repository release manifest is the configuration record.
- Return all assumptions, substitutions and exceptions explicitly; silence is not acceptance.

PRELIMINARY - CAPABILITY/DFM REQUEST ONLY - NOT A PURCHASE ORDER - DO NOT FABRICATE
