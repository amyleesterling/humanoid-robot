PROJECT BUTTON HR-V0 FABRICATION CAPABILITY / DFM INQUIRY

Packet: RFI-003
Routes: FAB-004 local secondary operation
Revision: HR-V0-FAB-RFI-P0.1
Status: PRELIMINARY - CAPABILITY/DFM REQUEST ONLY - NOT A PURCHASE ORDER - DO NOT FABRICATE

PURPOSE
Ask a local shop whether it can fixture traceable profile blanks, drill/mill the later-released finished geometry and support inspection. No work is authorized.

AUTHORIZATION BOUNDARY
- This packet requests capability, DFM, budgetary cost and lead-time information only.
- It is not a purchase order, request to start work, fabrication release or first-article authorization.
- Dimensions and tolerance notes remain preliminary. Critical finished-hole size and location tolerances remain SELECTION REQUIRED.
- Do not fabricate, procure material, program production, or infer omitted geometry from this packet.
- Any later work requires a separately signed authorization tied to an exact repository commit, drawing revision and SHA-256 manifest.

QUESTIONS TO RETURN IN WRITING
1. Identify the exact machine, workholding/datum strategy and operator/training route proposed for these parts.
2. Can the shop machine candidate 2.70 mm holes after final sizes/locations/tolerances are released? State achievable size and position capability.
3. Explain how blank identity and material traceability would be preserved across secondary machining.
4. List available calibrated inspection equipment, FAI records, supervision, scheduling, insurance/site rules and estimated cost.
5. Do not fabricate from this packet; return capability and DFM comments only.

CONFIGURATION CONTROL
- MANIFEST.csv hashes every payload file. It intentionally excludes README-FIRST.txt and itself.
- The commit containing this packet plus its outer repository release manifest is the configuration record.
- Return all assumptions, substitutions and exceptions explicitly; silence is not acceptance.

PRELIMINARY - CAPABILITY/DFM REQUEST ONLY - NOT A PURCHASE ORDER - DO NOT FABRICATE
