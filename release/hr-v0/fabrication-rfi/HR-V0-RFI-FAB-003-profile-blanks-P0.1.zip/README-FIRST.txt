PROJECT BUTTON HR-V0 FABRICATION CAPABILITY / DFM INQUIRY

Packet: RFI-002
Routes: FAB-003 profile operation only
Revision: HR-V0-FAB-RFI-P0.1
Status: PRELIMINARY - CAPABILITY/DFM REQUEST ONLY - NOT A PURCHASE ORDER - DO NOT FABRICATE

PURPOSE
Ask a profile-cutting supplier about producing deliberately hole-free blanks only. No finished holes or secondary machining are requested.

AUTHORIZATION BOUNDARY
- This packet requests capability, DFM, budgetary cost and lead-time information only.
- It is not a purchase order, request to start work, fabrication release or first-article authorization.
- Dimensions and tolerance notes remain preliminary. Critical finished-hole size and location tolerances remain SELECTION REQUIRED.
- Do not fabricate, procure material, program production, or infer omitted geometry from this packet.
- Any later work requires a separately signed authorization tied to an exact repository commit, drawing revision and SHA-256 manifest.

QUESTIONS TO RETURN IN WRITING
1. Can you profile-cut these zero-hole 6061-T6 blanks at the stated nominal thicknesses without adding or inferring any holes?
2. State available stock thicknesses/tolerances, profile tolerance, flatness basis, edge/deburr condition and material-certificate options.
3. Identify process lead-in, tab, edge, minimum-radius or file-preparation changes required for a later controlled first-blank order.
4. Provide budgetary cost and lead time for quantities 1, 1 and 1; this inquiry is not an order.

CONFIGURATION CONTROL
- MANIFEST.csv hashes every payload file. It intentionally excludes README-FIRST.txt and itself.
- The commit containing this packet plus its outer repository release manifest is the configuration record.
- Return all assumptions, substitutions and exceptions explicitly; silence is not acceptance.

PRELIMINARY - CAPABILITY/DFM REQUEST ONLY - NOT A PURCHASE ORDER - DO NOT FABRICATE
