# UNSENT Project Button Lot A inquiry — R257-RT-02

> **PRELIMINARY - NOT APPROVED FOR PROCUREMENT, FABRICATION, ASSEMBLY, CONNECTION, POWERED TESTING, MOTION, OR ENERGIZATION**

Intended organization: **ROBOTIS technical support**

Official public route: **cs@robotis.com; 949-377-0377**
Controlled scope: **R257-RQ-09..12** — technical assembly-document, hardware, torque/locking/reuse and response-authority questions.

This recipient-specific bundle is a frozen review candidate. It is **NOT AUTHORIZED** and **NOT SENT**. It is not an order, reservation, shipment instruction, work authorization, acceptance limit, assembly instruction or safety approval. Sender identity and reply address remain `SELECTION REQUIRED`.

Return only the included response workbooks with attributable, dated evidence. Do not substitute products, receive articles, incur cost, subcontract work or begin measurement without later configuration-specific written authority.
