# UNSENT Project Button Lot A inquiry — R257-RT-04

> **PRELIMINARY - NOT APPROVED FOR PROCUREMENT, FABRICATION, ASSEMBLY, CONNECTION, POWERED TESTING, MOTION, OR ENERGIZATION**

Intended organization: **3D ProScan, Clinton MA**

Official public route: **https://www.3dproscan.com/metrology-services.html; 978-365-8164**
Controlled scope: **33 route-specific questions plus R256-MZ-001..018** — exact-feature task-specific metrology capability and quotation.

This recipient-specific bundle is a frozen review candidate. It is **NOT AUTHORIZED** and **NOT SENT**. It is not an order, reservation, shipment instruction, work authorization, acceptance limit, assembly instruction or safety approval. Sender identity and reply address remain `SELECTION REQUIRED`.

Return only the included response workbooks with attributable, dated evidence. Do not substitute products, receive articles, incur cost, subcontract work or begin measurement without later configuration-specific written authority.
