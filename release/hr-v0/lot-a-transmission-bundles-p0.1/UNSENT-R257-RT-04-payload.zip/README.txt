PRELIMINARY - NOT APPROVED FOR PROCUREMENT, FABRICATION, ASSEMBLY, CONNECTION, POWERED TESTING, MOTION, OR ENERGIZATION

Bundle: HR-V0-LOT-A-TX-BUNDLE-P0.1
Route: R257-RT-04
Organization: 3D ProScan, Clinton MA
State: NOT AUTHORIZED / NOT SENT

Verify payload-manifest.csv before review. No file grants permission to contact, purchase, ship, assemble, connect, power, move or energize anything.
